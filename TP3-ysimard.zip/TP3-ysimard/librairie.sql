--
-- Database: `librairie`
--
CREATE DATABASE IF NOT EXISTS `librairie` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `librairie`;

-- --------------------------------------------------------

--
-- Table structure for table `categorie`
--

DROP TABLE IF EXISTS `categorie`;
CREATE TABLE IF NOT EXISTS `categorie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categorie`
--

INSERT INTO `categorie` (`id`, `nom`) VALUES
(1, 'Horreur'),
(2, 'Suspense'),
(3, 'Action'),
(4, 'Science fiction'),
(5, 'Fantaisie'),
(6, 'Fantastique'),
(7, 'Mystère');

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
CREATE TABLE IF NOT EXISTS `client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(25) NOT NULL,
  `prenom` varchar(25) NOT NULL,
  `adresse` varchar(50) NOT NULL,
  `code_postal` varchar(15) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `ville_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_client_ville1_idx` (`ville_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`id`, `nom`, `prenom`, `adresse`, `code_postal`, `phone`, `ville_id`) VALUES
(1, 'Steve', 'Bob', '3421 3e avenue', 'h3k 3m3', '514 823 0234', 1);

-- --------------------------------------------------------

--
-- Table structure for table `librairie`
--

DROP TABLE IF EXISTS `librairie`;
CREATE TABLE IF NOT EXISTS `librairie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(40) NOT NULL,
  `adresse` varchar(50) NOT NULL,
  `code_postal` varchar(15) NOT NULL,
  `ville_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_librairie_ville1_idx` (`ville_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `librairie`
--

INSERT INTO `librairie` (`id`, `nom`, `adresse`, `code_postal`, `ville_id`) VALUES
(1, 'librairie Le Renard perché', '3731 Ontario St E', 'H1W 1S3', 1);

-- --------------------------------------------------------

--
-- Table structure for table `livre`
--

DROP TABLE IF EXISTS `livre`;
CREATE TABLE IF NOT EXISTS `livre` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(50) NOT NULL,
  `auteur` varchar(50) NOT NULL,
  `nombre_pages` double DEFAULT NULL,
  `categorie_id` int(11) NOT NULL,
  `librairie_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_livre_categorie1_idx` (`categorie_id`),
  KEY `fk_livre_librairie1_idx` (`librairie_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `livre`
--

INSERT INTO `livre` (`id`, `titre`, `auteur`, `nombre_pages`, `categorie_id`, `librairie_id`) VALUES
(1, 'Les montagnes hallucinées', 'Howard Phillips Lovecraft', 64, 1, 1),
(2, 'Cent ans de solitude', 'Gabriel Garcia Marquez', 437, 6, 1),
(3, 'L\'ombre du vent', 'Carlos Ruiz Zafón', 505, 7, 1),
(4, 'Le Comte de Monte Cristo', 'Alexandre Dumas', 800, 2, 1),
(5, 'Le Cycle de Fondation', 'Isaac Asimov', 392, 4, 1),
(6, 'Le Seigneur des Anneaux Intégral', 'J.R.R. Tolkien', 1600, 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
CREATE TABLE IF NOT EXISTS `location` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datedebut` date NOT NULL,
  `datefin` date NOT NULL,
  `client_id` int(11) NOT NULL,
  `livre_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_commande_client1_idx` (`client_id`),
  KEY `fk_commande_livre1_idx` (`livre_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`id`, `datedebut`, `datefin`, `client_id`, `livre_id`) VALUES
(1, '2022-12-14', '2022-12-21', 1, 1),
(4, '2022-12-15', '2022-12-29', 1, 4),
(5, '2022-12-15', '2022-12-22', 1, 5);

-- --------------------------------------------------------

--
-- Table structure for table `privilege`
--

DROP TABLE IF EXISTS `privilege`;
CREATE TABLE IF NOT EXISTS `privilege` (
  `idprivilege` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(20) NOT NULL,
  PRIMARY KEY (`idprivilege`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `privilege`
--

INSERT INTO `privilege` (`idprivilege`, `nom`) VALUES
(1, 'master'),
(2, 'employee');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `iduser` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(45) NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(255) NOT NULL,
  `privilege_idprivilege` int(11) NOT NULL,
  PRIMARY KEY (`iduser`),
  KEY `fk_user_privilege1_idx` (`privilege_idprivilege`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`iduser`, `nom`, `username`, `password`, `privilege_idprivilege`) VALUES
(7, 'admin', 'admin@gmail.com', '$2y$10$IB7VIfFQ7B0jayFhpsoR6u1cIC0AN2Zi5FxC2LVHvJsaaXs6kqh1O', 1),
(11, 'Nathalie', 'nath@gmail.com', '$2y$10$21iaD6qjieXUCw8txNtXKuwFhX.eutO1yhns5MDkatQhuObQYf/iy', 2),
(13, 'Steve', 'steve@gmail.com', '$2y$10$tz5fzKvbcIoJSrxOSKv/m.6aKFUOj3jgj8udseaG3aMKe8U0Ly4/m', 2),
(14, 'Stevebob', 'bob@gmail.com', '$2y$10$7zK5LlJFFiEXGYH3.tvndOtBjuwpSJ4mxEnC2qeNwhViIXOFK6AV2', 2),
(15, 'Nathalie', 'nath90@gmail.com', '$2y$10$55kGzP7xMBt0FYrTo2uLyupgW2G78I1oQMePFHqifv3/HqHX5mAb6', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ville`
--

DROP TABLE IF EXISTS `ville`;
CREATE TABLE IF NOT EXISTS `ville` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ville`
--

INSERT INTO `ville` (`id`, `nom`) VALUES
(1, 'Montreal'),
(2, 'Laval'),
(3, 'Sherbrooke');

-- --------------------------------------------------------

--
-- Table structure for table `visitor_logs`
--

DROP TABLE IF EXISTS `visitor_logs`;
CREATE TABLE IF NOT EXISTS `visitor_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `page_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `referrer_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_ip_address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `user_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=207 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `visitor_logs`
--

INSERT INTO `visitor_logs` (`id`, `username`, `page_url`, `referrer_url`, `user_ip_address`, `user_agent`, `created`) VALUES
(14, 'admin@gmail.com', 'http://localhost/TP3-ysimard/TP2-ysimard/client/index', 'http://localhost/TP3-ysimard/TP2-ysimard/client', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0', '2022-12-15 15:02:34'),
(15, 'admin@gmail.com', 'http://localhost/TP3-ysimard/TP2-ysimard/client/index', 'http://localhost/TP3-ysimard/TP2-ysimard/client/index', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0', '2022-12-15 15:02:52');
--
-- Constraints for dumped tables
--

--
-- Constraints for table `client`
--
ALTER TABLE `client`
  ADD CONSTRAINT `fk_client_ville1` FOREIGN KEY (`ville_id`) REFERENCES `ville` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `librairie`
--
ALTER TABLE `librairie`
  ADD CONSTRAINT `fk_librairie_ville1` FOREIGN KEY (`ville_id`) REFERENCES `ville` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `livre`
--
ALTER TABLE `livre`
  ADD CONSTRAINT `fk_livre_categorie1` FOREIGN KEY (`categorie_id`) REFERENCES `categorie` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_livre_librairie1` FOREIGN KEY (`librairie_id`) REFERENCES `librairie` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `location`
--
ALTER TABLE `location`
  ADD CONSTRAINT `fk_commande_client1` FOREIGN KEY (`client_id`) REFERENCES `client` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_commande_livre1` FOREIGN KEY (`livre_id`) REFERENCES `livre` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `fk_user_privilege1` FOREIGN KEY (`privilege_idprivilege`) REFERENCES `privilege` (`idprivilege`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;
