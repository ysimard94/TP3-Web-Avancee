 <?php
session_start();
require_once __DIR__.'/library/RequirePage.php';
require_once __DIR__.'/vendor/autoload.php';
require_once __DIR__.'/library/Twig.php';
require_once __DIR__.'/library/Validation.php';
require_once __DIR__.'/library/CheckSession.php';
require_once 'controller/ControllerLog.php';

$url = isset($_GET["url"]) ? explode ('/', ltrim($_GET["url"], '/')) : '/';

// https://www.codexworld.com/store-visitor-log-in-the-database-with-php-mysql/
// Utilisé comme référence, mais modifié pour mon projet.
// Va insérer les informations de l'utilisateur dans la base de données à chaque fois qu'il visite une page
if(isset($_SESSION['username']))
{
    $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://"; 
    $username = $_SESSION['username'];
    $currentURL = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; 
    $user_ip_address = $_SERVER['REMOTE_ADDR']; 
    $referrer_url = !empty($_SERVER['HTTP_REFERER'])?$_SERVER['HTTP_REFERER']:'/';
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    
    $logArray = array(
        'username' => $username,
        'page_url' => $currentURL,
        'referrer_url' => $referrer_url,
        'user_ip_address' => $user_ip_address,
        'user_agent' => $user_agent
    );

    $controllerLog = new ControllerLog;
    $controllerLog->store($logArray);
}

// Si l'url ne contient qu'un backslash ( / ), envoyer l'utilisateur automatiquement à la page d'accueil qui contient la liste des locations
if($url == '/')
{
    require_once 'controller/ControllerHome.php';
    $controller = new ControllerHome;
    echo $controller->index();
}
// Sinon l'envoyer
else
{
    $requestURL = $url[0];
    $requestURL = ucfirst($requestURL);
    $controllerPath = __DIR__.'/controller/Controller'.$requestURL.'.php';

    if(file_exists($controllerPath)){
        require_once($controllerPath);
        $controllerName = 'Controller'.$requestURL;
        $controller = new $controllerName;
        if(isset($url[1])){
                $method = $url[1];
                if(isset($url[2])){
                    $value = $url[2];
                    echo $controller->$method($value);
                }else{
                    echo $controller->$method();
                }
        }else{
            echo $controller->index();
        }
        
    }else{
        require_once 'controller/ControllerHome.php';
        $controller = new ControllerHome;
        echo $controller->error();
    }
}
?>