<?php
RequirePage::requireModel('Crud');
RequirePage::requireModel('ModelClient');
RequirePage::requireModel('ModelVille');

class ControllerClient
{
    // Méthode qui va retourner l'utilisateur vers la page de liste de clients
    public function index()
    {
        $client = new ModelClient;
        $ville = new ModelVille;
        
        $selectClient = $client->select();
        $selectVille = $ville->select();

        twig::render("client-index.php", ['clients' => $selectClient,
                                          'villes' => $selectVille]);
    }

    // Méthode qui va retourner l'utilisateur vers la page de création de clients
    public function create(){
        $ville = new ModelVille;

        $selectVille = $ville->select();

        if(isset($_SESSION['username']))
        {
            if($_SESSION['privilege_idprivilege'] == 1 || $_SESSION['privilege_idprivilege'] == 2){
                twig::render('client-create.php', ['villes' => $selectVille]);
            }
        }
        else
        {
            requirePage::redirectPage('home');
        }
    }

    // Méthode qui va insérer un nouveau client dans la base de données
    public function store(){
        $client = new ModelClient;

        $insert = $client->insert($_POST);

        requirePage::redirectPage('client');
    }

    // Méthode qui va retourner l'utilisateur vers la page d'informations du client
    public function show($id){
        $client = new ModelClient;
        $ville = new ModelVille;

        $selectClient = $client->selectId($id);
        $selectVille = $ville->select();

        twig::render('client-show.php', ['client' => $selectClient,
                                         'villes' => $selectVille]);
    }

    // Méthode qui va retourner l'utilisateur vers la page de modification des informations client
    public function edit($id){
        $client = new ModelClient;
        $ville = new ModelVille;

        $selectClient = $client->selectId($id);
        $selectVille = $ville->select();
        twig::render('client-edit.php', ['client' => $selectClient,
                                         'villes' => $selectVille]);
    }

    // Méthode qui va mettre à jour les informations modifiées du client
    public function update(){
        $client = new ModelClient;
        $update = $client->update($_POST);
        RequirePage::redirectPage('client/show/'.$_POST['id']);
    }

    // Méthode qui va supprimer un client
    public function delete(){
        $client = new ModelClient;
        $delete = $client->delete($_POST['id']);
        RequirePage::redirectPage('client');
    }
}
?>
