<?php
RequirePage::requireModel('Crud');
RequirePage::requireModel('ModelUser');
RequirePage::requireModel('ModelPrivilege');

class ControllerUser{

    public function index()
    {
        $user = new ModelUser;
        $userSelect = $user->select('*', 'iduser');
        if(isset($_SESSION['username']))
        {
            if($_SESSION['privilege_idprivilege'] == 1 || $_SESSION['privilege_idprivilege'] == 2){
                twig::render('user-index.php', ['users' => $userSelect]);
            }
        }
        else
        {
            requirePage::redirectPage('home');
        }
    }

    public function create()
    {
        $privilege = new ModelPrivilege;
        $selectPrivilege = $privilege->select('*', 'idprivilege');

        if(isset($_SESSION['username']) && $_SESSION['privilege_idprivilege'] == 1)
        {
            twig::render('user-create.php', ['privileges' => $selectPrivilege]);
        }
        else
        {
            requirePage::redirectPage('home');
        }
        
    }
    public function store()
    {
        $idprivilege = 1;
        $user = new ModelUser;
        $userSelect = $user->select('username', 'username');
        $validation = new Validation;
        extract($_POST);
        $validation->name('nom')->value($nom)->pattern('alpha')->required()->max(45);
        $validation->name('username')->value($username)->pattern('email')->required()->max(50)->exists($username, $userSelect);
        $validation->name('password')->value($password)->max(20)->min(6);
        $validation->name('privilege_idprivilege')->value($idprivilege)->pattern('int')->required();
        
        if($validation->isSuccess())
        {
            $user = new ModelUser;
            $options = [
                'cost' => 10,
            ];
            $_POST['password']= password_hash($_POST['password'], PASSWORD_BCRYPT, $options);
            $userInsert = $user->insert($_POST);
            requirePage::redirectPage('user/login');
        }
        else
        {
            $errors = $validation->displayErrors();
            $privilege = new ModelPrivilege;
            $selectPrivilege = $privilege->select('*', 'idprivilege');
            // print_r($_POST);
            // print($errors);
            // die();
            twig::render('user-create.php', ['errors' => $errors,'privileges' => $selectPrivilege, 'user' => $_POST]);
        }
    }

    public function login()
    {
        twig::render('user-login.php');
    }

    public function auth()
    {
        $validation = new Validation;
        extract($_POST);
        $validation->name('username')->value($username)->pattern('email')->required()->max(50);
        $validation->name('password')->value($password)->required();
        
        if($validation->isSuccess())
        {
            $user = new ModelUser;
            $checkUser = $user->checkUser($_POST);

            twig::render('user-login.php', ['errors' => $checkUser, 'user' => $_POST]);
        }
        else
        {
            $errors = $validation->displayErrors();
            twig::render('user-login.php', ['errors' => $errors, 'user' => $_POST]);
        }
    }

    public function logout()
    {
        session_destroy();
        requirePage::redirectPage('user/login');
    }
}

?>