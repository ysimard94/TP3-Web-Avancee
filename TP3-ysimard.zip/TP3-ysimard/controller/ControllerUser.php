<?php
RequirePage::requireModel('Crud');
RequirePage::requireModel('ModelUser');
RequirePage::requireModel('ModelPrivilege');

class ControllerUser{

    // Méthode qui va retourner l'utilisateur vers la page index des utilisateurs si la personne est connectée et qu'elle a les privilèges nécessaires
    public function index()
    {
        $user = new ModelUser;
        $userSelect = $user->select('*', 'iduser');
        if(isset($_SESSION['username']))
        {
            if($_SESSION['privilege_idprivilege'] == 1 || $_SESSION['privilege_idprivilege'] == 2){
                twig::render('user-index.php', ['users' => $userSelect]);
            }
        }
        else
        {
            requirePage::redirectPage('home');
        }
    }

    // Méthode qui va permettre à l'administrateur d'aller sur la page de création d'utilisateur
    public function create()
    {
        $privilege = new ModelPrivilege;
        $selectPrivilege = $privilege->select('*', 'idprivilege');

        if(isset($_SESSION['username']) && $_SESSION['privilege_idprivilege'] == 1)
        {
            twig::render('user-create.php', ['privileges' => $selectPrivilege]);
        }
        else
        {
            requirePage::redirectPage('home');
        }
        
    }

    // Méthode qui va permettre à l'administrateur de créer un utilisateur
    public function store()
    {
        $idprivilege = 1;
        $user = new ModelUser;
        $userSelect = $user->select('username', 'username');
        $validation = new Validation;
        extract($_POST);

        // Validation des données envoyées par le formulaire
        $validation->name('nom')->value($nom)->pattern('alpha')->required()->max(45);
        $validation->name('username')->value($username)->pattern('email')->required()->max(50)->exists($username, $userSelect);
        $validation->name('password')->value($password)->max(20)->min(6);
        $validation->name('privilege_idprivilege')->value($idprivilege)->pattern('int')->required();
        
        // Si la validation est réussie, on insère les données dans la base de données
        if($validation->isSuccess())
        {
            $user = new ModelUser;
            $options = [
                'cost' => 10,
            ];
            $_POST['password']= password_hash($_POST['password'], PASSWORD_BCRYPT, $options);
            $userInsert = $user->insert($_POST);
            requirePage::redirectPage('user/login');
        }
        // Sinon, on retourne les erreurs et les données envoyées par le formulaire
        else
        {
            $errors = $validation->displayErrors();
            $privilege = new ModelPrivilege;
            $selectPrivilege = $privilege->select('*', 'idprivilege');

            twig::render('user-create.php', ['errors' => $errors,'privileges' => $selectPrivilege, 'user' => $_POST]);
        }
    }

    // Envoie vers la page de connexion
    public function login()
    {
        twig::render('user-login.php');
    }

    // Va valider les données envoyées par le formulaire de connexion et ensuite si la validation est réussie, va vérifier si l'utilisateur existe dans la base de données
    public function auth()
    {
        $validation = new Validation;
        extract($_POST);
        $validation->name('username')->value($username)->pattern('email')->required()->max(50);
        $validation->name('password')->value($password)->required();
        
        if($validation->isSuccess())
        {
            $user = new ModelUser;
            $checkUser = $user->checkUser($_POST);

            twig::render('user-login.php', ['errors' => $checkUser, 'user' => $_POST]);
        }
        else
        {
            $errors = $validation->displayErrors();
            twig::render('user-login.php', ['errors' => $errors, 'user' => $_POST]);
        }
    }

    // Méthode qui permet la déconnexion de l'utilisateur
    public function logout()
    {
        session_destroy();
        requirePage::redirectPage('user/login');
    }
}

?>