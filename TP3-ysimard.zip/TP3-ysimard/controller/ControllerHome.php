<?php
RequirePage::requireModel('Crud');
RequirePage::requireModel('ModelClient');
RequirePage::requireModel('ModelLivre');
RequirePage::requireModel('ModelLocation');

class ControllerHome{

    // Méthode qui va retourner le client sur la page d'accueil avec les informations des locations en cours
    public function index()
    {
        $client = new ModelClient;
        $livre = new ModelLivre;
        $location = new ModelLocation;
        
        $selectClient = $client->select();
        $selectLivre = $livre->select();
        $selectLocation = $location->select();


        twig::render("home-index.php", ['clients' => $selectClient,
                                        'livres' => $selectLivre,
                                        'locations' => $selectLocation]);
    }

    // Retourne l'utilisateur vers une page d'erreur
    public function error(){
        twig::render("home-error.php");
    }
}