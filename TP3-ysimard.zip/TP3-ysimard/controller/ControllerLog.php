<?php
RequirePage::requireModel('Crud');
RequirePage::requireModel('ModelLog');
RequirePage::requireModel('ModelClient');
RequirePage::requireModel('ModelLivre');
RequirePage::requireModel('ModelLocation');

class ControllerLog
{

    public function index()
    {
        $model = new ModelLog;
        $select = $model->select();

        if(isset($_SESSION['username']) && $_SESSION['privilege_idprivilege'] == 1)
        {
            twig::render('log-index.php', ['users' => $select]);
        }
        else
        {
            requirePage::redirectPage('home');
        }
    }

    public function store($array)
    {

        $model = new ModelLog;
        // Insert visitor log into database 
        $insert = $model->insert($array);
    }
}