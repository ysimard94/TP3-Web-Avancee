<?php
RequirePage::requireModel('Crud');
RequirePage::requireModel('ModelLog');
RequirePage::requireModel('ModelClient');
RequirePage::requireModel('ModelLivre');
RequirePage::requireModel('ModelLocation');

class ControllerLog
{

    // Méthode qui envoie vers la page de log avec les données des logs
    public function index()
    {
        $model = new ModelLog;
        $select = $model->select();

        if(isset($_SESSION['username']) && $_SESSION['privilege_idprivilege'] == 1)
        {
            twig::render('log-index.php', ['users' => $select]);
        }
        else
        {
            requirePage::redirectPage('home');
        }
    }

    // Va insérer les données du log dans la base de données
    public function store($array)
    {
        $model = new ModelLog;

        $insert = $model->insert($array);
    }
}