<?php
RequirePage::requireModel('Crud');
RequirePage::requireModel('ModelLivre');
RequirePage::requireModel('ModelCategorie');

class ControllerLivre{

    // Méthode qui va retourner l'utilisateur vers la page de liste des livres dans la base de données
    public function index(){

        $livre = new ModelLivre;
        $categorie = new ModelCategorie;

    
        $selectLivre = $livre->select();
        $selectCategorie = $categorie->select();


        twig::render("livre-index.php", ['livres' => $selectLivre,
                                         'categories' => $selectCategorie]);
      }
}