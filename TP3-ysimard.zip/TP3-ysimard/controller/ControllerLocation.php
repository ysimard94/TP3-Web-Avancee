<?php
RequirePage::requireModel('Crud');
RequirePage::requireModel('ModelClient');
RequirePage::requireModel('ModelLivre');
RequirePage::requireModel('ModelLocation');

class ControllerLocation{

    // Méthode qui va envoyer l'utilisateur vers la page pour créer de nouvelles locations
    public function create(){
        $client = new ModelClient;
        $livre = new ModelLivre;

        $selectClient = $client->select();
        $selectLivre = $livre->select();

        // J'insère la date de début ainsi qu'une date de fin de location
        // de 7 à 14 jours tout dépendant de l'option choisi par le client
        $datedebut = date("Y-m-d");
        $datefin7 = strtotime("+7 day");
        $datefin7 = date("Y-m-d", $datefin7);
        $datefin14 = strtotime("+14 day");
        $datefin14 = date("Y-m-d", $datefin14);

        if(isset($_SESSION['username']))
        {
            if($_SESSION['privilege_idprivilege'] == 1 || $_SESSION['privilege_idprivilege'] == 2){
                twig::render('location-create.php', ['clients' => $selectClient,
                                             'livres' => $selectLivre,
                                             'datedebut' => $datedebut,
                                             'datefin7' => $datefin7,
                                             'datefin14' => $datefin14]);
            }
        }
        else
        {
            requirePage::redirectPage('home');
        }
        
                        
    }

    // Méthode qui va insérer la location créée dans la base de données
    public function store(){
        $location = new ModelLocation;

        $insert = $location->insert($_POST);
   
        requirePage::redirectPage('home');
    }

    // Méthode qui va supprimer la location de la base de données
    public function delete(){
        $client = new ModelLocation;
        $delete = $client->delete($_POST['id']);
        RequirePage::redirectPage('home');
    }
}