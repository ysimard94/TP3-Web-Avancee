<?php
RequirePage::requireModel('Crud');
RequirePage::requireModel('fpdf');
RequirePage::requireModel('ModelLocation');

class ControllerFpdf
{
    // http://www.fpdf.org/en/tutorial/tuto5.htm
    // Référencé le lien ci-dessus pour créer la méthode qui va générer le pdf
    public function index()
    {
        $client = new ModelClient;
        $livre = new ModelLivre;
        $location = new ModelLocation;
        $data = array();
        
        $selectClient = $client->select();
        $selectLivre = $livre->select();
        $selectLocation = $location->select();

        foreach($selectLocation as $location )
        {
            $tempArray = array(
                'client_id' => '',
                'livre_id' => '',
                'datedebut' => $location['datedebut'],
                'datefin' => $location['datefin']
            );

            foreach($selectClient as $client )
            {
                if($location['client_id'] == $client['id'])
                {
                    $tempArray['client_id'] = $client['prenom'] . " " .  $client['nom'];
                }
            }

            foreach($selectLivre as $livre )
            {
                if($location['livre_id'] == $livre['id'])
                {
                    $tempArray['livre_id'] = $livre['titre'];
                }
            }
            array_push($data, $tempArray);
        }

        $pdf = new FPDF('L','mm','A4');
        $header = array('Nom', 'Livres', 'Date debut', 'Date fin');
        $pdf->AddPage();
        // Fonction custom qui va boucler dans le tableau $data et afficher un tableau avec celui-ci
        $pdf->BasicTable($header,$data);
        $pdf->Output();
    }
}