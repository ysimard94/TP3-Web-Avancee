{{ include('header.php', {title: 'Edit Client', pageHeader:'Modifier'})}}
    <main>
        <h1>Liste d'utilisateurs </h1>
        <table>
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>Nom d'utilisateur</th>
                </tr>
            </thead>
            <tbody>
                    {% for user in users %}
                    <tr>
                        <td>{{user.nom}}</td>
                        <td>{{user.username}}</td>
                    {% endfor %} 
            </tbody>
        </table>
    </main>
</body>
</html>