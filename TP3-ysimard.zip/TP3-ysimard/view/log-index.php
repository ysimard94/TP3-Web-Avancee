{{ include('header.php') }}
    <main>
        <h1>Log des utilisateurs </h1>
        <table>
            <thead>
                <tr>
                    <th>Utilisateur</th>
                    <th>Page visitée</th>
                    <th>Page référée</th>
                    <th>Adresse IP</th>
                    <th>Navigateur</th>
                    <th>Date visitée</th>
                </tr>
            </thead>
            <tbody>
                    {% for user in users %}
                    <tr>
                        <td>{{user.username}}</td>
                        <td>{{user.page_url}}</td>
                        <td>{{user.referrer_url}}</td>
                        <td>{{user.user_ip_address}}</td>
                        <td>{{user.user_agent}}</td>
                        <td>{{user.created}}</td>
                    </tr>
                    {% endfor %} 
            </tbody>
        </table>
    </main>
</body>
</html>