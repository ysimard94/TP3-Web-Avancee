{{ include('header.php', {title: 'User', pageHeader: 'Créer un utilisateur'})}}
    <main>
        <span class="error">{{ errors|raw }}</span>
        <form action="{{ path }}user/store" method="post">
            <label>Nom 
                <input type="text" name="nom">
            </label>
            <label>Username 
                <input type="email" name="username" value="{{ user.username }}">
            </label>
            <label>Password 
                <input type="password" name="password">
            </label>

            {%  if session.privilege_idprivilege == 1 %}
            <label>Privilege 
                {{ privilege }}
                <select name="privilege_idprivilege">
                    <option value="">Select</option>
                    {% for privilege in privileges %}
                    <option value="{{ privilege.idprivilege }}">{{ privilege.nom }}</option>
                    {% endfor %}
                </select>
            </label>
            {% endif %}

            <input type="submit" value="Sauvegarder">
        </form>
    </main>
</body>
</html>