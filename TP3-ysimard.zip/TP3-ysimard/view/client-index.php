{{ include('header.php', {title: 'Edit Client', pageHeader:'Modifier'})}}
    <main>
        <h1>Liste de Client </h1>
        <table>
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>Adresse</th>
                    <th>Code Postal</th>
                    <th>Téléphone</th>
                    <th>Ville</th>
                </tr>
            </thead>
            <tbody>
                <?php echo $_SESSION['iduser'] ?>
                    {% for client in clients %}
                    <tr>
                        <td><a href="{{ path }}client/show/{{client.id}}">{{client.prenom}} {{client.nom}}</a></td>
                        <td>{{client.adresse}}</td>
                        <td>{{client.code_postal}}</td>
                        <td>{{client.phone}}</td>
 
                        <td>
                        {% for ville in villes %}
                            {% if client.ville_id == ville.id %}
                            {{ ville.nom }}
                            {% endif %}
                        {% endfor %}
                        </td>
                    </tr>
                    {% endfor %} 
            </tbody>
        </table>
    </main>
</body>
</html>