{{ include('header.php', {title: 'Edit Client', pageHeader:'Liste des locations'})}}
<body>
    <h3 class='error'>404 Not Found</h3>
</body>
</html>