{{ include('header.php', {title: 'Edit Client', pageHeader:'Liste des locations'})}}
    <main>
        <h1>Liste des locations</h1>
        <table>
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>Livre</th>
                    <th>Date début</th>
                    <th>Date fin</th>
                </tr>
            </thead>
            <tbody>
                {% for location in locations %}
                    <tr>
                        <td>
                        {% for client in clients %}
                            {% if location.client_id == client.id %}
                                {{ client.prenom }} {{ client.nom }}
                            {% endif %}
                        {% endfor %}
                        </td>
                        <td>
                        {% for livre in livres %}
                            {% if location.livre_id == livre.id %}
                                {{ livre.titre }}
                            {% endif %}
                        {% endfor %}
                        </td>
                        <td>{{ location.datedebut }}</td>
                        <td>{{ location.datefin }}</td>
                        {% if session.privilege_idprivilege == 1 or session.privilege_idprivilege == 2 %}
                        <td>
                            <form action="{{ path }}location/delete" method="post">
                                <input type="hidden" name="id" value="{{ location.id }}">
                                <input type="submit" value="Effacer">
                            </form> 
                        </td>
                        {% endif %}
                    </tr>
                {% endfor %}
            </tbody>
        </table>
        <a href="{{ path }}fpdf">Enregistrer la liste de locations</a>
    </main>
</body>
</html>