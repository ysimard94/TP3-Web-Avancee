<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier le client</title>
    <link rel="stylesheet" href="{{ path }}css/style.css">
</head>
<body>
    <nav>
        <span class="welcome">
            {% if session %}
                Bienvenue {{ session.nom }}
            {% endif %}
        </span>
        <a href="{{ path }}home/index">Liste des locations</a>
        <a href="{{ path }}client/index">Liste des clients</a>
        <a href="{{ path }}livre/index">Liste des livres</a>

        {% if session.privilege_idprivilege == 1 or session.privilege_idprivilege == 2 %}
        <a href="{{ path }}location/create">Insérer une location</a>
        <a href="{{ path }}client/create">Créer un nouveau client</a>
        <a href="{{ path }}user">Utilisateurs</a>
        {% endif %}


        {% if session.privilege_idprivilege == 1 %}
        <a href="{{ path }}log">Log</a>
        <a href="{{ path }}user/create">Create</a>
        {% endif %}

        {% if guest %}
        <a href="{{ path }}user/login">Login</a>
        {% else %}
        <a href="{{ path }}user/logout">Logout</a>
        {% endif %}
    </nav>