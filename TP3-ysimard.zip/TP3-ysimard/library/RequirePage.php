<?php

class RequirePage{

    // Méthode qui sert de require_once
    static public function requireModel($model)
    {
        return require_once "model/$model.php";
    }

    // Méthode de redirection de page avec les données spécifiées
    static public function redirectPage($page)
    {
        return header("Location: http://localhost/TP3-ysimard/TP3-ysimard/".$page);
    }
}

?>