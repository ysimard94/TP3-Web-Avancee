<?php
class ModelLocation extends Crud
{
    protected $table = 'location';
    protected $primaryKey = 'id';

    protected $fillable = ['id', 'client_id', 'livre_id', 'datedebut', 'datefin'];
}
