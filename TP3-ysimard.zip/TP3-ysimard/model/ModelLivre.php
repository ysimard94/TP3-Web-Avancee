<?php
class ModelLivre extends Crud 
{
    protected $table = 'livre';
    protected $primaryKey = 'id';
}
?>