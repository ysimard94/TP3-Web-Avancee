<?php
class ModelClient extends Crud 
{
    protected $table = 'client';
    protected $primaryKey = 'id';

    protected $fillable = ['id', 'nom', 'prenom', 'adresse', 'code_postal', 'phone', 'ville_id'];
}
?>  