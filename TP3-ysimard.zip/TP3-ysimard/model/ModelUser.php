<?php

class ModelUser extends Crud {

    protected $table = 'user';
    protected $primaryKey = 'iduser';

    protected $fillable = ['iduser', 'nom', 'username', 'password', 'privilege_idprivilege'];

    public function checkUser($data){
        extract($data);
        $sql = "SELECT * FROM $this->table WHERE username = ?";
        $stmt = $this->prepare($sql);
        $stmt->execute(array($username));
        $count = $stmt->rowCount();
        if($count == 1){
            $user_info = $stmt->fetch();
            if(password_verify($password, $user_info['password'])){
                    
                session_regenerate_id();
                $_SESSION['iduser'] = $user_info['iduser'];
                $_SESSION['privilege_idprivilege'] = $user_info['privilege_idprivilege'];
                $_SESSION['nom'] = $user_info['nom'];
                $_SESSION['username'] = $user_info['username'];
                $_SESSION['fingerPrint'] = md5($_SERVER['HTTP_USER_AGENT'] . $_SERVER['REMOTE_ADDR']);
                requirePage::redirectPage('client');
                
            }else{
               return "<ul><li>Verifier le mot de passe</li></ul>";  
            }
        }else{
            return "<ul><li>Le nom d'utilisateur n'exist pas</li></ul>";
        }
    } 
}

?>