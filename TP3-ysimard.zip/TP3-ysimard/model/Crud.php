<?php

abstract class Crud extends PDO 
{
    // Configuration de la connexion vers la base de données
    public function __construct()
    {
        parent::__construct('mysql:host=localhost; dbname=librairie; port=3306; charset=utf8', 'root', '');
    }

    // Va retourner les informations de la table selon les champs spécifiés
    public function select($selection = '*', $field='id', $order='ASC' )
    {
        $sql = "SELECT $selection FROM $this->table ORDER BY $field $order";
        $stmt  = $this->query($sql);
        // print_r($stmt);
        // die();
        return  $stmt->fetchAll();
    }

    // Va retourner la valeur d'un champ si la comparaison correspond à un des champs spécifiés
    public function selectCompare($id, $col='*', $table)
    {
        $sql = "SELECT $col FROM $table WHERE $id = id";
        $stmt  = $this->query($sql);
        return  $stmt->fetch();
    }

    // Va servir à retourner un tableau de manière sécure à l'aide des méthodes PDO pour éviter qu'un utilisateur puisse envoyer des requêtes
    // avec la méthode GET qui pourraient toucher à la base de données
    public function selectId($value)
    {
        $sql ="SELECT * FROM $this->table WHERE $this->primaryKey = :$this->primaryKey";
        $stmt = $this->prepare($sql);
        $stmt->bindValue(":$this->primaryKey", $value);
        $stmt->execute();
        $count = $stmt->rowCount();

        if($count == 1 )
        {
            return $stmt->fetch();
        }
        else
        {
            header("location: ../../home/error");
        }
    }


    // Méthode qui sert à insérer les données envoyées dans la table spécifiée de la base de données
    public function insert($data)
    {
        $data_keys = array_fill_keys($this->fillable, '');
        $data_map = array_intersect_key($data, $data_keys);
        $nomChamp = implode(", ",array_keys($data_map));
        $valeurChamp = ":".implode(", :", array_keys($data_map));
        $sql = "INSERT INTO $this->table ($nomChamp) VALUES ($valeurChamp)";
        $stmt = $this->prepare($sql);
        
        foreach($data_map as $key=>$value)
        {
            $stmt->bindValue(":$key", $value);
        }
        
        if(!$stmt->execute())
        {
            print_r($stmt->errorInfo());
        }
        else
        {
            return $this->lastInsertId();
        }
    }
    
    // Méthode pour mettre à jour les informations d'une donnée déjà enregistrée
    public function update($data)
    {

        $champRequete = null;
        foreach($data as $key=>$value)
        {
            $champRequete .= "$key = :$key, ";
        }
        $champRequete = rtrim($champRequete, ", ");

        $sql = "UPDATE $this->table SET $champRequete WHERE $this->primaryKey = :$this->primaryKey";

        $stmt = $this->prepare($sql);
        foreach($data as $key=>$value)
        {
            $stmt->bindValue(":$key", $value);
        } 

        if(!$stmt->execute())
        {
            print_r($stmt->errorInfo());
        }
        else
        {
           // header('Location: ' . $_SERVER['HTTP_REFERER']);
           return true;
        }
    }

    // Méthode pour supprimer le champ d'une table avec la valeur renvoyée
    public function delete($id)
    {
        $sql = "DELETE FROM $this->table WHERE $this->primaryKey = :$this->primaryKey";

        $stmt = $this->prepare($sql);
        $stmt->bindValue(":$this->primaryKey", $id);

        if(!$stmt->execute())
        {
            print_r($stmt->errorInfo());
        }
        else
        {
            return true;
        }
    }
}
?>