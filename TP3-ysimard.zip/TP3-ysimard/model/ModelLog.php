<?php
class ModelLog extends Crud
{
    protected $table = 'visitor_logs';
    protected $primaryKey = 'id';

    protected $fillable = ['username', 'page_url', 'referrer_url', 'user_ip_address', 'user_agent', 'created'];
}