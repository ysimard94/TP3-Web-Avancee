<?php

class ModelPrivilege extends Crud {

    protected $table = 'privilege';
    protected $primaryKey = 'idprivilege';
}

?>